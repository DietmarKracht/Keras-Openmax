# Keras-Openmax
Openmax Implementation with Keras provided as a pip module
